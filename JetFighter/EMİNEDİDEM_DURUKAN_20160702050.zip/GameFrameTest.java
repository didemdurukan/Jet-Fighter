import javax.swing.JFrame;
import java.awt.FlowLayout;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.ImageIcon;
import javax.swing.Icon;
import javax.swing.JButton;

public class GameFrameTest {
	
	public static void main(String args[]) {
		
		
		GameFrame menu = new GameFrame();
		menu.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		menu.setSize(600,600);
		menu.setVisible(true);
		
		
		
		
	}

}
